#include<stdio.h>
#include<time.h>
#include<string.h>
#include<stdlib.h>
#include "arrayio.h"
#include "sort.h"



int main()
{	
	DateInit();
	int ch,choice;
	clock_t start, finish;
	double  duration;
A:
	system("cls");
	printf("��ѡ����Ҫ���Ե�����\n");
	printf("1.��������\n2.�鲢����\n3.��������\n4.��������\n5.������������\n");
	scanf("%d", &ch);
	while (ch < 1 || ch>5)
	{
		printf("������ѡ��");
		scanf("%d", &ch);
	}
	printf("��ѡ����Ҫ���Ե���Ŀ��1.10000������ 2.50000������ 3.200000������ 4.100*100k������\n");
	scanf("%d", &choice);
	while (choice < 1 || choice>4)
	{
		printf("������ѡ��");
		scanf("%d", &choice);
	}
	if (ch == 1)
	{
		if (choice == 1)
		{
			choice = 10000;
			int* p1 = (int*)malloc(sizeof(int) * 10000);
			if (p1 == NULL) {
				return;
			}
			int* p2 = p1;
			//int array3[200000];
			readData(p2, 10000);
			start = clock();
			insertSort(p2, 10000);
			finish = clock();
			duration = (double)(finish - start) / CLOCKS_PER_SEC;
			printf("%f seconds\n", duration);
			system("pause");
		}
		else if (choice == 2)
		{
			choice = 50000;
			int array2[50000];
			readData(array2, 50000);
			start = clock();
			insertSort(array2, 50000);
			finish = clock();
			duration = (double)(finish - start) / CLOCKS_PER_SEC;
			printf("%f seconds\n", duration);
			system("pause");
		}
		else if (choice == 3)
		{
			choice = 200000;
			int* p1 = (int*)malloc(sizeof(int) * 200000);
			if (p1 == NULL) {
				return;
			}
			int* p2 = p1;
			//int array3[200000];
			readData(p2, 200000);
			start = clock();
			insertSort(p2, 200000);
			finish = clock();
			duration = (double)(finish - start) / CLOCKS_PER_SEC;
			printf("%f seconds\n", duration);
			system("pause");
		}
		else
		{

		}
		goto A;
		
	}
	else if (ch == 2)
	{
		if (choice == 1)
		{
			choice = 10000;
			int* p1 = (int*)malloc(sizeof(int) * 10000);
			if (p1 == NULL) {
				return;
			}
			int* p2 = p1;
			//int array3[200000];
			readData(p2, 10000);
			start = clock();
			merge_Sort(p2, 10000); 
			finish = clock();
			duration = (double)(finish - start) / CLOCKS_PER_SEC;
			printf("%f seconds\n", duration);
			system("pause");
		}
		else if (choice == 2)
		{
			choice = 50000;
			int* p1 = (int*)malloc(sizeof(int) * 50000);
			if (p1 == NULL) {
				return;
			}
			int* p2 = p1;
			readData(p2, 50000);
			start = clock();
			merge_Sort(p2, 50000);
			finish = clock();
			duration = (double)(finish - start) / CLOCKS_PER_SEC;
			printf("%f seconds\n", duration);
			system("pause");
		}
		else if (choice == 3)
		{
			choice = 200000;
			int* p1 = (int*)malloc(sizeof(int) * 200000);
			if (p1 == NULL) {
				return;
			}
			int* p2 = p1;
			//int array3[200000];
			readData(p2, 200000);
			start = clock();
			merge_Sort(p2, 200000);
			finish = clock();
			duration = (double)(finish - start) / CLOCKS_PER_SEC;
			printf("%f seconds\n", duration);
			system("pause");
		}
		else
		{

		}
		goto A;
	}
	else if (ch == 3)
	{
		if (choice == 1)
		{
			choice = 10000;
			int* p1 = (int*)malloc(sizeof(int) * 10000);
			if (p1 == NULL) {
				return;
			}
			int* p2 = p1;
			//int array3[200000];
			readData(p2, 10000);
			start = clock();
			//insertSort(p2, 10000);
			quickSort(p2, 1, choice);
			finish = clock();
			duration = (double)(finish - start) / CLOCKS_PER_SEC;
			printf("%f seconds\n", duration);
			system("pause");
		}
		else if (choice == 2)
		{
			choice = 50000;
			int* p1 = (int*)malloc(sizeof(int) * 50000);
			if (p1 == NULL) {
				return;
			}
			int* p2 = p1;
			readData(p2, 50000);
			start = clock();
			quickSort(p2, 1, choice);
			finish = clock();
			duration = (double)(finish - start) / CLOCKS_PER_SEC;
			printf("%f seconds\n", duration);
			system("pause");
		}
		else if (choice == 3)
		{
			choice = 200000;
			int* p1 = (int*)malloc(sizeof(int) * 200000);
			if (p1 == NULL) {
				return;
			}
			int* p2 = p1;
			//int array3[200000];
			readData(p2, 200000);
			start = clock();
			quickSort(p2, 1, choice);
			finish = clock();
			duration = (double)(finish - start) / CLOCKS_PER_SEC;
			printf("%f seconds\n", duration);
			system("pause");
		}
		else
		{

		}
		goto A;
	}
	else if(ch==4)
	{
		if (choice == 1)
		{
			choice = 10000;
			int* p1 = (int*)malloc(sizeof(int) * 10000);
			if (p1 == NULL) {
				return;
			}
			int* p2 = p1;
			//int array3[200000];
			readData(p2, 10000);
			start = clock();
			//insertSort(p2, 10000);
			base_Sort(p2, choice);
			finish = clock();
			duration = (double)(finish - start) / CLOCKS_PER_SEC;
			printf("%f seconds\n", duration);
			system("pause");
		}
		else if (choice == 2)
		{
			choice = 50000;
			int* p1 = (int*)malloc(sizeof(int) * 50000);
			if (p1 == NULL) {
				return;
			}
			int* p2 = p1;
			readData(p2, 50000);
			start = clock();
			base_Sort(p2, choice);
			finish = clock();
			duration = (double)(finish - start) / CLOCKS_PER_SEC;
			printf("%f seconds\n", duration);
			system("pause");
		}
		else if (choice == 3)
		{
			choice = 200000;
			int* p1 = (int*)malloc(sizeof(int) * 200000);
			if (p1 == NULL) {
				return;
			}
			int* p2 = p1;
			//int array3[200000];
			readData(p2, choice);
			start = clock();
			base_Sort(p2, choice);
			finish = clock();
			duration = (double)(finish - start) / CLOCKS_PER_SEC;
			printf("%f seconds\n", duration);
			system("pause");
		}
		else
		{

		}
		goto A;
	}
	else if(ch==5)
	{
		if (choice == 1)
		{
			choice = 10000;
			int* p1 = (int*)malloc(sizeof(int) * 10000);
			if (p1 == NULL) {
				return;
			}
			int* p2 = p1;
			//int array3[200000];
			readData(p2, 10000);
			start = clock();
			//insertSort(p2, 10000);
			counting_Sort(p2, choice);
			finish = clock();
			duration = (double)(finish - start) / CLOCKS_PER_SEC;
			printf("%f seconds\n", duration);
			system("pause");
		}
		else if (choice == 2)
		{
			choice = 50000;
			int array2[50000];
			readData(array2, 50000);
			start = clock();
			counting_Sort(array2, choice);
			finish = clock();
			duration = (double)(finish - start) / CLOCKS_PER_SEC;
			printf("%f seconds\n", duration);
			system("pause");
		}
		else if (choice == 3)
		{
			choice = 200000;
			int* p1 = (int*)malloc(sizeof(int) * 200000);
			if (p1 == NULL) {
				return;
			}
			int* p2 = p1;
			//int array3[200000];
			readData(p2, 200000);
			start = clock();
			counting_Sort(p2, choice);
			finish = clock();
			duration = (double)(finish - start) / CLOCKS_PER_SEC;
			printf("%f seconds\n", duration);
			system("pause");
		}
		else
		{

		}
		goto A;
	}
	

}
